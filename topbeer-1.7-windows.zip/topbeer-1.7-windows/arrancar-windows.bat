@echo off
REM TOPBEER - arranca el panel en Windows.
REM Para que arranque solo al encender, pulsa Win+R, escribe shell:startup
REM y crea aqui un acceso directo a este fichero.
title TOPBEER
cd /d "%~dp0"
topbeer-windows-amd64.exe --port 8080
if errorlevel 1 (
  echo.
  echo No se pudo arrancar. Puede que el puerto 8080 este ocupado.
  echo Prueba con otro:   topbeer-windows-amd64.exe --port 8000
  echo.
  pause
)
