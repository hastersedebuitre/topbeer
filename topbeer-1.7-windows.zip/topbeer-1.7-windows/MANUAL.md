# TOPBEER — panel split-flap de barriles

Panel estilo tablero de aeropuerto (Solari / split-flap) para la pared de una
cervecería, con sonido de aletas al cambiar los datos. En lugar de vuelos
muestra los barriles que hay en los grifos.

Se gestiona desde el móvil, por la propia wifi del local, con usuario y
contraseña. Lo que se guarda aparece en el TV en menos de dos segundos, con la
animación completa de las aletas.

---

## Qué necesita

* Un PC, portátil o **Raspberry Pi** conectado al TV por HDMI.
* Nada más que el propio ejecutable — no necesita ningún intérprete ni librería.
* Wifi o cable en la misma red que el móvil del encargado.
* No necesita internet. Funciona con el router aislado.

## Puesta en marcha

**Windows:** doble clic en `arrancar-windows.bat`.

**Raspberry Pi y Linux:**

```bash
./topbeer-rpi-arm64        # o el que corresponda a tu equipo
```

En la terminal aparecen las dos direcciones:

```
  Panel (TV) .... http://192.168.1.50:8080/
  Gestión ....... http://192.168.1.50:8080/admin

  Usuario: admin   Contraseña: password
```

* **El TV** abre la primera dirección a pantalla completa.
* **El móvil** abre la segunda, entra con usuario y contraseña y edita.

Cambia el puerto con `--port 8000` si el 8080 está ocupado.

> La primera vez se crea la carpeta `data/` con diez cervezas de ejemplo para
> que el panel se vea lleno desde el primer segundo. Bórralas y pon las tuyas.

**Cambia la contraseña antes de instalarlo en un local.** Gestión → Cuenta.
Mientras no lo hagas, un aviso amarillo te lo recuerda en cada pantalla.

---

## El panel (TV)

### Enseñar un estilo sin cambiar el del local

El panel acepta ajustes por la dirección, sin tocar lo guardado:

```
http://IP:8080/?estilo=madera
http://IP:8080/?estilo=pizarra&titulo=La%20Taberna
http://IP:8080/?estilo=aeropuerto&color=verde&desfase_letra=14
```

Sirve para enseñarle los tres estilos a un cliente desde el portátil mientras
el TV del local sigue con el suyo. Admite `estilo`, `color`, `titulo`, `sub1`,
`sub2`, `sub3`, `mensaje`, `filas`, `velocidad`, `desfase_fila`,
`desfase_letra` y `pasos`.

| Tecla / gesto | Efecto |
|---|---|
| Un clic | Activa el sonido y arranca el tablero |
| Doble clic o `F` | Pantalla completa |
| `R` | Recarga los datos a mano |
| `S` | Hace girar el tablero entero (para enseñárselo a un cliente) |
| La tecla del mensaje | Lanza el mensaje sorpresa (ver abajo) |

### El mensaje sorpresa

Se configura en Gestión → Panel → **Mensaje sorpresa**: el texto (una línea por
renglón del tablero), la tecla que lo dispara y cuántos segundos dura.

Al pulsar esa tecla en el TV, el panel **deja de ser una carta de cervezas**:

* En el tablero de aeropuerto lo escriben **las propias aletas**, a lo ancho y
  saltándose las columnas, centrado en la pantalla. Con su sonido.
* En madera y pizarra aparece en grande, con la letra del estilo, sobre un velo
  del color del propio tablero.

Pasados los segundos vuelve solo a la carta. Mientras dura, los cambios que
lleguen desde el móvil esperan: no lo pisan.

F, R y S no valen como tecla, ya hacen otra cosa.

**El color del mensaje** se elige aparte, en el mismo sitio. En *automático*
usa el que mejor va con cada estilo (ámbar en aeropuerto, marrón oscuro sobre
madera, blanco tiza en pizarra), pero puedes poner el que quieras: en los
estilos de madera, un color mal elegido se pierde contra el fondo, y ahí es
donde conviene jugar con esto. El mensaje se escribe siempre sobre un velo del
color del propio tablero, para que destaque sobre la carta.

> El alfabeto de las aletas incluye la **Ñ**, así que «FELIZ CUMPLEAÑOS» sale
> entero. Las vocales acentuadas sí se quedan sin tilde en el tablero de
> aeropuerto (un panel de verdad tampoco las tiene); en madera y pizarra salen
> tal cual las escribas.

Si hay más barriles que filas, el panel pagina solo y muestra `PAG 1/2` arriba
a la derecha. Si el servidor se cae, aparece un aviso rojo en la esquina; los
datos siguen en pantalla hasta que vuelva.

### El sonido

Las aletas suenan al girar, con un golpe sintetizado en el propio navegador.
**No hay ficheros de audio que cargar y no se distribuye ninguna grabación
ajena**, pero el sonido no es inventado: está calcado de las medidas de una
grabación real de un split-flap.

Lo que dijo el análisis de esa grabación (94 golpes aislados):

| Medida | Valor |
|---|---|
| Cuerpo del golpe | 200-350 Hz, con segundo formante sobre 450 |
| Chasquido de la lámina | pico estrecho en 4 kHz |
| Por encima de 9 kHz | casi nada |
| Caída a la mitad | 16 ms; apagado sobre los 85 ms |
| Entre aleta y aleta | **100 ms** |

Un golpe mecánico no es un tono: es un impulso excitando resonancias. Por eso
el sintetizador es ruido impulsivo pasado por un banco de siete filtros, no
osciladores. Los valores se ajustaron midiendo hasta dejar el error de
espectro en 0,065 (partía de 0,372).

Los seis golpes se **renderizan una sola vez al arrancar** y durante el giro
solo se reproducen, con variación de tono: dos nodos de audio por golpe, para
que una Raspberry Pi aguante un tablero entero girando.

De ahí sale también el ritmo de fábrica: **100 ms entre aletas y 26 vueltas
por letra**, que es lo que hace un panel de verdad.

### La tipografía del tablero

El tablero de aeropuerto usa una **condensada de verdad** (Roboto Condensed,
con respaldo a Liberation Sans Narrow y DejaVu Sans Condensed), no una
monoespaciada deformada. Importa más de lo que parece: deformar una fuente con
`scaleY` para hacerla estrecha rompe sus proporciones y **se come los acentos**
— la tilde de la Ñ se salía de la aleta y se recortaba. Con una condensada
nativa los acentos caen donde deben.

Como cada aleta tiene ancho fijo por CSS, la fuente no necesita ser
monoespaciada: cada letra se centra en su aleta. El volumen sube cuantas más aletas giran
a la vez, igual que en un tablero real. Se apaga desde Gestión → Panel.

**Suena cada vez que giran aletas**, que son tres momentos:

* Al estrenar el tablero, cuando se llena entero. Es el más aparatoso.
* **Cada vez que se guarda un cambio desde el móvil** — y solo giran las aletas
  de lo que ha cambiado, como en un tablero de verdad: cambiar un precio suena
  a cuatro clacs, cambiar la cerveza entera suena a una ráfaga.
* Al cambiar de página, si hay más barriles que filas.

**El panel no pide permiso con ninguna pantalla.** El interruptor de sonido
está en Gestión → Panel, y ahí se queda.

Los navegadores no dejan sonar nada hasta que reciben un gesto. El panel lo
intenta al cargar y, si se lo bloquean, se engancha al primer clic, toque o
tecla que reciba, sin avisar de nada. En modo kiosco con
`--autoplay-policy=no-user-gesture-required` no hace falta ni eso.

Para ajustar el volumen sin esperar a un cambio, Gestión → Panel →
**Probar sonido aquí**: suena en el propio móvil.

---

## La gestión (móvil)

Tres pestañas abajo:

**Grifos** — la lista. Toca uno para editarlo: número de grifo, cerveza, tipo,
fabricante, precio de caña y de pinta, grados, país y estado. El interruptor
*Visible en el panel* lo oculta del TV sin borrarlo (útil para el barril que
vuelve la semana que viene). Las flechas ▲▼ cambian el orden.

**Panel** — el aspecto:

* **Estilo del tablero**, lo primero (ver abajo).
* Título grande y las tres líneas pequeñas de la izquierda.
* **Logotipo de la cervecería** — PNG, JPG, WEBP o SVG hasta 3 MB. Con fondo
  transparente queda mejor.
* Color del tablero: ámbar, blanco, verde o mixto (solo en estilo Aeropuerto;
  madera, piedra y pizarra traen su propia paleta).
* **Acabado de la madera** (tablón o listones), cuando el estilo es Madera.
* **Tema de temporada**: normal, Navidad o Halloween (ver abajo).
* Filas visibles, símbolo de moneda, cada cuánto cambia de página.
* **Se anima sola**: cada cuánto repite el giro entero sin que cambie nada.
* **Tiempos del efecto flip-flap** (ver abajo).
* Sonido, volumen y un botón para probarlo en el móvil. Reloj.
* **Mensaje sorpresa**: el texto, la tecla que lo lanza, lo que dura y su color.
* Mensaje del pie, que se desplaza (ofertas, wifi, cata del mes).
* Columnas: cuáles se ven y cuánto ocupa cada una. Si quitas columnas, las
  demás se agrandan en el TV.

**Cuenta** — usuario, contraseña y las direcciones del panel.

Los cambios no se envían hasta pulsar **Guardar**: una barra naranja avisa
mientras haya algo pendiente.

### Los cuatro estilos

Se eligen desde Gestión → Panel y cambian al instante en el TV. El mecanismo
de aletas es el mismo en todos: lo que cambia es el material.

| Estilo | Qué parece | Para qué local |
|---|---|---|
| **Aeropuerto** | Aletas negras con letras ámbar, como un Solari de los 70 | Taproom, cervecería moderna, sitio con punto gamberro |
| **Madera** | Carta tallada o grabada en madera, con dos acabados a elegir | Taberna, asador, sitio rústico |
| **Piedra** | Muro de piedra real (foto), con el rótulo tallado. Dos acabados: mampostería o sillares | Sitio con piedra vista, bodega, sidrería |
| **Pizarra de café** | Una carta escrita a tiza, con marco de madera y dibujos | Restaurante, bistró, gastrobar, cafetería |

**Madera, piedra y pizarra no son el tablero repintado: son otra vista.** No
hay aletas ni rejilla. Cada cerveza ocupa dos líneas —el nombre grande, los
datos pequeños debajo— con una guía de puntos que lleva la vista hasta el
precio, a dos columnas, igual que la carta de un café.

Cuando cambia un dato no gira nada: la línea **se borra y se vuelve a
escribir**, con un sonido distinto según el material — tiza, rascado de
madera o el golpe seco de un cincel en piedra — en vez del clac de la aleta.
**El efecto de aletas solo lo tiene el estilo Aeropuerto.**

#### Madera: dos acabados

Al elegir Madera aparece un segundo selector, **Tablón / Listones**:

| Acabado | Qué es |
|---|---|
| **Tablón** | Un único tablón de fondo, la carta grabada a fuego encima |
| **Listones** | Un listón de madera por cerveza, cada renglón en su tabla |

La madera lleva nudos, la veta se desvía al pasarlos y el tono cambia a lo
largo de la tabla: una madera uniforme se nota falsa enseguida. En listones hay
**cuatro tablas distintas** que se van alternando, con los nudos en sitios
diferentes y la veta a otra inclinación, y las dos columnas van desfasadas para
que no queden dos iguales una al lado de la otra. La letra va en cursiva oscura
con la luz justo debajo, como un pirograbado, y al escribirse **sube una voluta
de humo** de la línea mientras la letra queda un instante al rojo, como la
punta del pirógrafo.

#### Piedra

Una foto real de un muro, no un dibujo: un degradado o un patrón generado
nunca iba a tener el grano de un mineral de verdad ni su luz. Dos acabados,
el mismo selector de Gestión que el de la madera:

| Acabado | Qué es |
|---|---|
| **Mampostería** | Bloques toscos e irregulares, como un cierre de finca gallego |
| **Sillares** | Piedra plana en hiladas, más clara y con más margen de lectura |

Las dos fotos son de [Poly Haven](https://polyhaven.com), bajo licencia
**CC0** (dominio público: se pueden usar en un producto que se vende, sin
atribución). Van en `static/piedra-muro.jpg` y `static/piedra-sillares.jpg`,
~635 KB cada una a 1024×1024 — de sobra para un televisor normal. El origen
y la licencia están anotados en `static/LICENSE-CC0-texturas.txt`.

El rótulo va en mayúsculas, tallado — sombra donde entra el cincel, un filo
de luz justo debajo —, con la misma condensada del aeropuerto: ya tiene el
aire de una lápida o un rótulo monumental, así que no añade ninguna
tipografía nueva al programa.

**Color de la letra** — en el mismo subselector, debajo de los dos acabados.
Una foto no siempre deja el tono oscuro de serie lo bastante legible; aquí se
elige el color de toda la letra del estilo Piedra de una vez (título,
nombres, precios, detalle), igual que el color del mensaje sorpresa: un
selector de color y un botón *Automático* para volver al de serie.

#### La letra manuscrita

Para madera y pizarra, la letra manuscrita (**Caveat** para el cuerpo,
**Dancing Script** para el título) va **incluida en el programa**. No se
descarga de internet al abrir la página: una Raspberry Pi en un bar puede no
tener ninguna fuente manuscrita y puede no tener línea.

En los estilos de carta escribe los nombres como quieras verlos (`Punk IPA`,
no `PUNK IPA`): el tablero de aletas los pasa a mayúsculas él solo, pero la
carta respeta lo que escribas.

### Temporada: Navidad y Halloween

En Gestión → Panel → **Tema de temporada**: Normal, Navidad o Halloween.

Añade una escena en una esquina del panel, sin tocar nada más: el estilo, los
colores y los datos siguen como los tengas.

* **Navidad** — una rama de acebo con bayas y lucecitas cálidas, un
  arbolito con bolas de cristal semitransparentes, y **nieve cayendo** por
  toda la pantalla: cuarenta copos de seis puntas (trazo vectorial, no el
  carácter ❄ — una Raspberry Pi pelada puede no tener esa fuente), cada uno
  con su propio tamaño, velocidad de caída y balanceo.
* **Halloween** — una calabaza con resplandor de vela en la esquina, **un
  marco de telaraña permanente** arriba del todo (dos rincones con su
  tejido y una guirnalda de festones colgando entre ellos, como el borde de
  una invitación de Halloween), y **una araña bajando por su hilo**: una
  sola, nunca varias a la vez, con el hilo alargándose de verdad desde
  arriba hasta que llega abajo del todo — no es un adorno que se desliza,
  es el propio borde de una caja cuya altura crece con el tiempo.

La nieve es puro CSS en bucle infinito — nada que recalcular por fotograma
desde JavaScript — así que no cuesta nada ni en una Raspberry Pi. La araña sí
anima un alto (la única forma de que el hilo *crezca* de verdad), pero al ser
una sola, el coste es insignificante.

Se elige a mano, no por la fecha del equipo: así no depende de que el reloj
del televisor esté bien puesto, y tú decides cuándo empieza y cuándo acaba
la temporada.

### Los tiempos del efecto

Cuatro números, en Gestión → Panel. Debajo verás en vivo cuánto tarda el
tablero en llenarse con los valores que elijas.

| Ajuste | Qué hace |
|---|---|
| **Aleta a aleta** | Milisegundos entre una aleta y la siguiente dentro de una letra. Bájalo y el giro es frenético; súbelo y es ceremonioso |
| **Vueltas por letra** | Cuántas aletas gira como mucho cada letra antes de parar en la suya. Es el «recorrido» |
| **Fila a fila** | Retardo entre una fila y la de abajo. Es lo que da la cascada de arriba abajo |
| **Letra a letra** | Retardo entre una letra y la de su derecha |
| **Desigualdad entre letras** | A cero todas giran igual y paran a la vez. Alto, unas cuantas se rezagan: el tablero casi lleno con media docena de letras aún dando vueltas |
| **Altura de la letra** | Estira la letra a lo alto sin ensancharla. Tope 120: más arriba, la tilde de la Ñ no cabe en la aleta |

### Repetir la animación sola

En Gestión → Panel → **Repetir la animación sola**: cada 30 segundos, cada
minuto, cada media hora o lo que elijas, el tablero vuelve a girar entero
aunque no haya cambiado ningún dato.

Es lo que hace girar la cabeza a quien pasa por delante, y en un bar vale más
que cualquier otra cosa del panel. No interrumpe el mensaje sorpresa ni un giro
que siga en marcha: espera a que acabe.

**Letra a letra en 0** (lo de serie) hace que cada fila gire **entera de golpe**
y las filas se encadenen de arriba abajo, como un panel de verdad. Súbelo a 10
o 15 si prefieres la cascada en diagonal.

Cada aleta tiene su propio carácter, fijo: una va suelta y otra cuesta. No es
azar momentáneo, es que esa aleta concreta es lenta durante todo el giro, así
que se queda rezagada de verdad en lugar de temblar.

### Estados y colores

| Estado | Color en el TV |
|---|---|
| DISPONIBLE | verde |
| ULTIMOS LITROS | naranja, parpadea |
| AGOTADA | rojo |
| NOVEDAD | azul |
| PROXIMAMENTE | lila |
| EN FRIO / RESERVADA | el color del tablero |

El parpadeo de *ULTIMOS LITROS* es el que más vende: la gente pide esa.

---

## Instalar en una Raspberry Pi

`instalar.sh` deja el panel arrancando solo al encender:

```bash
sudo ./instalar.sh
```

Crea un servicio `systemd` llamado `topbeer` y explica cómo dejar el navegador
en modo kiosco. Para controlarlo después:

```bash
sudo systemctl status topbeer
sudo systemctl restart topbeer
sudo journalctl -u topbeer -f
```

### Modo kiosco (el TV sin barras ni ratón)

En la Raspberry, añade a `~/.config/autostart/topbeer.desktop`:

```ini
[Desktop Entry]
Type=Application
Name=TOPBEER
Exec=chromium-browser --kiosk --noerrdialogs --disable-infobars --autoplay-policy=no-user-gesture-required --incognito http://localhost:8080/
X-GNOME-Autostart-enabled=true
```

`--autoplay-policy=no-user-gesture-required` hace que el sonido funcione sin
tener que tocar la pantalla. Conviene desactivar también el salvapantallas:

```bash
sudo apt install unclutter
echo -e "@xset s off\n@xset -dpms\n@xset s noblank\n@unclutter -idle 0" >> ~/.config/lxsession/LXDE-pi/autostart
```

---

## Copias de seguridad

Todo vive en dos sitios:

* `data/` — cervezas, ajustes, credenciales y el logotipo (en `data/uploads/`).

Esa única carpeta es la copia de seguridad completa.

Copiar esas dos carpetas es la copia de seguridad completa. Para montar un
segundo local, cópialas y cambia el título.

---

## Licencia del programa

Sin registrar, el panel funciona **entero** pero muestra una marca roja
**DEMO** en la esquina. Al registrarlo desaparece y no vuelve.

### Para el cliente

Gestión → Cuenta → **Licencia**: pega el bloque que recibiste y pulsa
Registrar. Se queda guardado en `data/licencia.txt`.

### Para ti, que lo vendes

```bash
./generar-licencia -guardar "maria@barlaplaza.es" "Bar La Plaza"
```

Imprime el bloque que le envías al cliente y, con `--guardar`, anota la venta
en `licencias/vendidas.json`. Cada licencia lleva correo, nombre del local, un
id único y la fecha.

**La carpeta `licencias/` no se reparte nunca.** Ahí está la clave privada
RSA-2048 con la que se firman. El producto solo lleva la pública: puede
comprobar una licencia, pero no fabricarla. `herramientas/` y
`licencias/` están en el `.gitignore` por eso mismo.

Si pierdes `licencias/claves.json` no podrás emitir licencias nuevas que
funcionen con las copias ya vendidas. **Haz copia de esa carpeta.**

> **Hasta dónde protege.** Esto frena la copia casual: un cliente que pasa la
> carpeta a otro bar se encuentra el DEMO, y nadie puede fabricarse una
> licencia sin tu clave privada. No frena a alguien decidido: el programa es
> un binario compilado que alguien muy decidido podría desensamblar. Es el nivel normal
> en software de nicho. Para ir más allá haría falta activación en línea
> contra un servidor tuyo, que es otro producto y otra factura.

## Seguridad

Pensado para la red del local, no para publicarlo en internet.

* El panel del TV es público dentro de la red (no pide contraseña: es un
  cartel). La gestión sí.
* La contraseña se guarda con PBKDF2-SHA256 (120 000 iteraciones) y sal
  aleatoria. Nunca en claro.
* La sesión es una cookie firmada con HMAC, `HttpOnly` y `SameSite=Lax`, válida
  30 días.
* Diez intentos de acceso fallidos por IP cada cinco minutos.
* Todo lo que se escribe se recorta y se limpia antes de guardarlo; los anchos,
  velocidades y colores se validan contra sus límites.
* Las imágenes solo se aceptan como PNG, JPG, WEBP, GIF o SVG, hasta 3 MB.

**Si quieres abrirlo desde fuera del local**, ponlo detrás de un túnel
(Tailscale, WireGuard) o de un proxy con HTTPS. Tal cual va por HTTP: dentro de
la wifi del local es razonable, expuesto a internet no.

---

## Ficheros

```
topbeer-*         el programa, un fichero por plataforma
instalar.sh        deja el panel como servicio (Linux y Raspberry Pi)
arrancar-windows.bat   lo arranca en Windows
generar-licencia   emite licencias — NO SE REPARTE
licencias/         clave privada y registro de ventas — NO SE REPARTE
(El HTML, el CSS, el JavaScript y las tipografías van **dentro** del binario.)
  admin.css        interfaz del móvil
  admin.js         lógica de la gestión
  uploads/         logotipos subidos
data/              se crea sola: config.json, taps.json, auth.json, secret.key
```

El código es propio: no reutiliza nada de los proyectos de referencia
(`baspete/Split-Flap`, `pmnilsson/flight-board-card`), así que no arrastra
obligaciones de licencia de terceros.

Las dos fuentes de `static/fonts/` son de terceros, bajo **SIL Open Font
License 1.1** (el texto está en `static/fonts/LICENSE-OFL.txt`). La OFL permite
incluirlas en un producto que vendas y no obliga a abrir tu código; lo único
que prohíbe es vender las fuentes sueltas. Si quieres evitar hasta eso, borra
la carpeta: el modo pizarra cae en la caligráfica del sistema y los otros dos
estilos ni la usan.
