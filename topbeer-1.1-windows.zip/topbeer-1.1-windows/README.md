# TOPBEER

**Panel de cervezas estilo tablero de aeropuerto, para la pared de tu local.**

Un tablero split-flap como los de las estaciones: las letras giran una a una,
con su sonido de aletas, pero en lugar de vuelos muestra los barriles que
tienes en los grifos. Se gestiona desde el móvil, por la wifi del bar.

![Panel](capturas/aeropuerto.png)

---

## Qué hace

* **Cuatro estilos**: tablero de aeropuerto, carta grabada en un tablón de
  madera, carta en listones de madera, y pizarra de café escrita a tiza.
* **Se cambia desde el móvil**: entras con usuario y contraseña, tocas un
  grifo, lo editas y el TV lo muestra en menos de dos segundos, con toda la
  animación.
* **Suena como un panel de verdad**: el golpe de las aletas está sintetizado a
  partir de las medidas de una grabación real (200-350 Hz de cuerpo, pico de
  chasquido en 4 kHz, 100 ms entre aleta y aleta).
* **Logotipo de tu cervecería**, colores, tiempos del efecto, columnas
  visibles, mensaje en el pie.
* **Mensaje sorpresa**: pulsas una tecla y el tablero escribe lo que quieras
  con sus propias aletas. Un cumpleaños, una pedida, lo que se tercie.
* **Se anima solo** cada tanto —30 segundos, media hora, lo que elijas— aunque
  no haya cambiado nada. Es lo que hace girar la cabeza a quien pasa.

## Qué necesitas

* Un PC, portátil o **Raspberry Pi** conectado al TV por HDMI.
* **Nada más.** Es un único fichero ejecutable: no hay que instalar nada, ni
  librerías, ni internet.
* Estar en la misma red que el móvil del encargado.

Hay un paquete por plataforma: **Windows**, **Raspberry Pi** y **PC Linux**.

## Ponerlo en marcha

**Windows** — doble clic en `arrancar-windows.bat`.

**Raspberry Pi / Linux** — abre una terminal en la carpeta y:

```
./topbeer-rpi-arm64
```

La terminal te da las dos direcciones:

```
  Panel (TV) .... http://192.168.1.50:8080/
  Gestión ....... http://192.168.1.50:8080/admin

  Usuario: admin   Contraseña: password
```

El TV abre la primera a pantalla completa. El móvil abre la segunda.

Viene con diez cervezas de ejemplo para que lo veas funcionando desde el primer
segundo. La contraseña inicial es literalmente `password`: **cámbiala** antes de
dejarlo en un local, en Gestión → Cuenta. El propio panel te lo recuerda con un
aviso hasta que lo hagas.

En Raspberry Pi y Linux, `sudo ./instalar.sh` lo deja arrancando solo al
encender el equipo. En Windows, crea un acceso directo a
`arrancar-windows.bat` dentro de `shell:startup`.

Todo el detalle está en [MANUAL.md](MANUAL.md): estilos, tiempos, modo kiosco,
copias de seguridad y seguridad.

## Esta versión es de prueba

Funciona **entera**, sin recortes ni caducidad. Lo único: el panel muestra una
marca **DEMO** en la esquina.

Para quitarla hace falta una licencia. Se registra en Gestión → Cuenta →
Licencia, pegando el bloque que recibes al comprarla, y ya no vuelve a
aparecer. Cada licencia va a nombre de un local y un correo.

**Para comprarla, escribe a TU-CORREO-AQUI.**

## Licencias de terceros

El programa es propio. Las tres tipografías que lleva dentro son de terceros,
bajo **SIL Open Font License 1.1**: Roboto Condensed, Caveat y Dancing Script.
Sus textos de licencia están accesibles en el propio panel, en
`/static/fonts/`.
